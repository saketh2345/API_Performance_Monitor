# API Performance Monitor

## Features
- Check any HTTP/HTTPS API endpoint
- Measure response time in milliseconds
- Record HTTP status code and request errors
- Store checks in SQLite
- Dashboard with total checks, successful checks, success rate, and average response time
- JSON endpoints for metrics and summary

## Run
```bash
cd api_performance_monitor
python -m venv venv
# Windows: venv\Scripts\activate
# macOS/Linux: source venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000 and enter an API URL such as `https://api.github.com`.

## API usage
Check an endpoint:
```bash
curl -X POST http://127.0.0.1:5000/api/check \
-H "Content-Type: application/json" \
-d "{\"url\":\"https://api.github.com\"}"
```
Get recorded metrics:
```bash
curl http://127.0.0.1:5000/api/metrics
```
Get summary:
```bash
curl http://127.0.0.1:5000/api/summary
```
Clear records:
```bash
curl -X POST http://127.0.0.1:5000/api/metrics/clear
```

## Notes
- Each API check has a 10-second timeout.
- A response with HTTP status 200–399 is counted as successful.
- This educational project performs checks when requested. To monitor automatically at fixed intervals, add a scheduler such as APScheduler or Celery.
- For production use, add authentication, request limits, HTTPS, URL allow-listing, and protection against server-side request forgery (SSRF). Do not expose this demo monitor as a public unrestricted URL-fetching service.
