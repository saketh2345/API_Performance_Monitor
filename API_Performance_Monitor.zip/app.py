import os
import sqlite3
import time
from datetime import datetime, timezone
from urllib.parse import urlparse

import requests
from flask import Flask, jsonify, request, render_template, g

app = Flask(__name__)
DB_PATH = os.path.join(os.path.dirname(__file__), "monitor.db")

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(_error):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    with sqlite3.connect(DB_PATH) as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS api_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT NOT NULL,
                status_code INTEGER,
                response_time_ms REAL NOT NULL,
                success INTEGER NOT NULL,
                error TEXT,
                checked_at TEXT NOT NULL
            )
        """)

def valid_url(url):
    parsed = urlparse(url)
    return parsed.scheme in ("http", "https") and bool(parsed.netloc)

@app.route("/")
def dashboard():
    rows = get_db().execute(
        "SELECT * FROM api_metrics ORDER BY id DESC LIMIT 50"
    ).fetchall()
    stats = get_db().execute("""
        SELECT COUNT(*) AS total,
               SUM(CASE WHEN success=1 THEN 1 ELSE 0 END) AS successful,
               AVG(response_time_ms) AS avg_time
        FROM api_metrics
    """).fetchone()
    total = stats["total"] or 0
    successful = stats["successful"] or 0
    success_rate = round(successful * 100 / total, 1) if total else 0
    return render_template("dashboard.html", rows=rows, total=total,
                           successful=successful, success_rate=success_rate,
                           avg_time=round(stats["avg_time"] or 0, 2))

@app.route("/api/check", methods=["POST"])
def check_api():
    data = request.get_json(silent=True) or {}
    url = str(data.get("url", "")).strip()
    if not valid_url(url):
        return jsonify({"error": "Provide a valid http:// or https:// URL"}), 400

    started = time.perf_counter()
    status_code = None
    error = None
    success = 0
    try:
        response = requests.get(url, timeout=10)
        status_code = response.status_code
        success = 1 if 200 <= status_code < 400 else 0
    except requests.RequestException as exc:
        error = str(exc)[:500]
    elapsed_ms = round((time.perf_counter() - started) * 1000, 2)

    checked_at = datetime.now(timezone.utc).isoformat()
    db = get_db()
    cur = db.execute("""
        INSERT INTO api_metrics (url, status_code, response_time_ms, success, error, checked_at)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (url, status_code, elapsed_ms, success, error, checked_at))
    db.commit()

    return jsonify({
        "id": cur.lastrowid, "url": url, "status_code": status_code,
        "response_time_ms": elapsed_ms, "success": bool(success),
        "error": error, "checked_at": checked_at
    }), 200

@app.route("/api/metrics", methods=["GET"])
def metrics():
    rows = get_db().execute(
        "SELECT * FROM api_metrics ORDER BY id DESC LIMIT 100"
    ).fetchall()
    return jsonify([dict(row) for row in rows])

@app.route("/api/summary", methods=["GET"])
def summary():
    result = get_db().execute("""
        SELECT COUNT(*) AS total,
               SUM(CASE WHEN success=1 THEN 1 ELSE 0 END) AS successful,
               AVG(response_time_ms) AS avg_response_time,
               MAX(response_time_ms) AS max_response_time
        FROM api_metrics
    """).fetchone()
    total = result["total"] or 0
    successful = result["successful"] or 0
    return jsonify({
        "total_requests": total,
        "successful_requests": successful,
        "failed_requests": total - successful,
        "success_rate_percent": round(successful * 100 / total, 2) if total else 0,
        "average_response_time_ms": round(result["avg_response_time"] or 0, 2),
        "maximum_response_time_ms": round(result["max_response_time"] or 0, 2)
    })

@app.route("/api/metrics/clear", methods=["POST"])
def clear_metrics():
    get_db().execute("DELETE FROM api_metrics")
    get_db().commit()
    return jsonify({"message": "All monitoring records cleared"})

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
